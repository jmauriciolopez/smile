import { Module } from '@nestjs/common';
import { PacientesModule } from './modulos/pacientes/pacientes.module';
import { CasosModule } from './modulos/casos/casos.module';
import { PresupuestosModule } from './modulos/presupuestos/presupuestos.module';
import { SeguimientosModule } from './modulos/seguimientos/seguimientos.module';
import { AutenticacionModule } from './modulos/autenticacion/autenticacion.module';

@Module({
  imports: [
    AutenticacionModule,
    PacientesModule,
    CasosModule,
    PresupuestosModule,
    SeguimientosModule,
  ],
})
export class AppModule {}
