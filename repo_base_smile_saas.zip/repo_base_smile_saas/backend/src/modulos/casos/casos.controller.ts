import { Controller, Get } from '@nestjs/common';
import { CasosService } from './casos.service';

@Controller('casos')
export class CasosController {
  constructor(private readonly casosService: CasosService) {}

  @Get()
  obtenerTodos() {
    return this.casosService.obtenerTodos();
  }
}
