import { Injectable } from '@nestjs/common';
import { CrearPacienteDto } from './dto/crear_paciente.dto';
import { ActualizarPacienteDto } from './dto/actualizar_paciente.dto';

@Injectable()
export class PacientesService {
  obtenerTodos() {
    return [];
  }

  obtenerPorId(id: string) {
    return { id };
  }

  crear(dto: CrearPacienteDto) {
    return dto;
  }

  actualizar(id: string, dto: ActualizarPacienteDto) {
    return { id, ...dto };
  }
}
