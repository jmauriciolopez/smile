import { Injectable } from '@nestjs/common';
import { IniciarSesionDto } from './dto/iniciar_sesion.dto';

@Injectable()
export class AutenticacionService {
  iniciarSesion(dto: IniciarSesionDto) {
    return {
      access_token: 'token-demo',
      usuario: {
        email: dto.email,
        rol: 'administrador',
      },
    };
  }
}
