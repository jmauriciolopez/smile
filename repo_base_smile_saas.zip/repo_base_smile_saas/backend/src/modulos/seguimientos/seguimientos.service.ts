import { Injectable } from '@nestjs/common';

@Injectable()
export class SeguimientosService {
  obtenerTodos() {
    return [];
  }
}
