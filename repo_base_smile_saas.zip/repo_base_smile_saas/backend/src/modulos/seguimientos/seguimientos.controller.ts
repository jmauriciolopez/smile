import { Controller, Get } from '@nestjs/common';
import { SeguimientosService } from './seguimientos.service';

@Controller('seguimientos')
export class SeguimientosController {
  constructor(private readonly seguimientosService: SeguimientosService) {}

  @Get()
  obtenerTodos() {
    return this.seguimientosService.obtenerTodos();
  }
}
