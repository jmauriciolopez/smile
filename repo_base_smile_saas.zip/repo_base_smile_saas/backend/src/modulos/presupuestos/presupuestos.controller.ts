import { Controller, Get } from '@nestjs/common';
import { PresupuestosService } from './presupuestos.service';

@Controller('presupuestos')
export class PresupuestosController {
  constructor(private readonly presupuestosService: PresupuestosService) {}

  @Get()
  obtenerTodos() {
    return this.presupuestosService.obtenerTodos();
  }
}
