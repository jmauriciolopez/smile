# Repo base — SaaS Diseño de Sonrisa

Monorepo base con:

- `frontend/` → React + TypeScript + Tailwind + React Router
- `backend/` → NestJS + Prisma + PostgreSQL
- nombres en español
- estructura alineada al master playbook
- módulos base listos para crecer

## Estructura

```txt
repo_base_smile_saas/
  frontend/
  backend/
```

## Frontend

Incluye:
- shell base
- layout premium simple
- rutas
- módulos vacíos
- servicios
- hooks
- store de autenticación
- componentes base en español

## Backend

Incluye:
- módulos NestJS base
- Prisma schema inicial
- DTOs en español
- autenticación base preparada
- estructura modular

## Puesta en marcha sugerida

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Backend
```bash
cd backend
npm install
cp .env.ejemplo .env
npm run prisma:generate
npm run prisma:migrate
npm run start:dev
```

## Nota

Es un repo base listo para abrir y empezar a desarrollar.
No incluye todavía lógica compleja del editor ni integración real de archivos.
