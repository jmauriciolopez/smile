import { Routes, Route, Navigate } from 'react-router-dom';
import { ShellAplicacion } from '../componentes/layout/ShellAplicacion';
import { DashboardPage } from '../modulos/dashboard/paginas/DashboardPage';
import { PacientesPage } from '../modulos/pacientes/paginas/PacientesPage';
import { CasosPage } from '../modulos/casos/paginas/CasosPage';
import { EditorSonrisaPage } from '../modulos/diseno_sonrisa/paginas/EditorSonrisaPage';
import { PresupuestosPage } from '../modulos/presupuestos/paginas/PresupuestosPage';
import { SeguimientosPage } from '../modulos/seguimientos/paginas/SeguimientosPage';
import { LoginPage } from '../modulos/autenticacion/paginas/LoginPage';

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ShellAplicacion />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/pacientes" element={<PacientesPage />} />
        <Route path="/casos" element={<CasosPage />} />
        <Route path="/disenos/editor" element={<EditorSonrisaPage />} />
        <Route path="/presupuestos" element={<PresupuestosPage />} />
        <Route path="/seguimientos" element={<SeguimientosPage />} />
      </Route>
    </Routes>
  );
}
