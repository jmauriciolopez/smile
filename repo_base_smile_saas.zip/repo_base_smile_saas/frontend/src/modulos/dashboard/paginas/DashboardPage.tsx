import { Card } from '../../../componentes/ui/Card';

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <p className="mt-1 text-textoSecundario">Resumen operativo y comercial.</p>
      </header>

      <div className="grid gap-4 md:grid-cols-4">
        <Card titulo="Pacientes activos"><div className="text-3xl font-bold">24</div></Card>
        <Card titulo="Casos abiertos"><div className="text-3xl font-bold">12</div></Card>
        <Card titulo="Presupuestos"><div className="text-3xl font-bold">8</div></Card>
        <Card titulo="Seguimientos"><div className="text-3xl font-bold">6</div></Card>
      </div>
    </div>
  );
}
