import { Card } from '../../../componentes/ui/Card';

export function SeguimientosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Seguimientos</h1>
        <p className="mt-1 text-textoSecundario">Timeline comercial y próximas acciones.</p>
      </header>

      <Card titulo="Timeline">
        <div className="text-sm text-textoSecundario">
          Acá va el registro de seguimientos comerciales.
        </div>
      </Card>
    </div>
  );
}
