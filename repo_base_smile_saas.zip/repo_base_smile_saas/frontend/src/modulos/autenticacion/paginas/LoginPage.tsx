export function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-fondo p-6">
      <div className="w-full max-w-md rounded-2xl bg-superficie p-8 shadow-suave">
        <h1 className="text-2xl font-semibold">Iniciar sesión</h1>
        <p className="mt-2 text-sm text-textoSecundario">
          Pantalla base para autenticación.
        </p>
      </div>
    </div>
  );
}
