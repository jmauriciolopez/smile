import { Card } from '../../../componentes/ui/Card';

export function PacientesPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Pacientes</h1>
        <p className="mt-1 text-textoSecundario">Listado base para futura integración.</p>
      </header>

      <Card titulo="Listado">
        <div className="text-sm text-textoSecundario">
          Acá va el listado real de pacientes conectado a API.
        </div>
      </Card>
    </div>
  );
}
