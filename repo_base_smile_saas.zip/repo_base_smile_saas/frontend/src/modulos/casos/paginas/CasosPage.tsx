import { Card } from '../../../componentes/ui/Card';

export function CasosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Casos clínicos</h1>
        <p className="mt-1 text-textoSecundario">Centro operativo de cada tratamiento.</p>
      </header>

      <Card titulo="Casos">
        <div className="text-sm text-textoSecundario">
          Acá va el listado o detalle de casos clínicos.
        </div>
      </Card>
    </div>
  );
}
