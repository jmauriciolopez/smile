import { Card } from '../../../componentes/ui/Card';

export function PresupuestosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Presupuestos</h1>
        <p className="mt-1 text-textoSecundario">Opciones de tratamiento y cierre.</p>
      </header>

      <Card titulo="Presupuesto">
        <div className="text-sm text-textoSecundario">
          Acá va el detalle real del presupuesto y sus opciones.
        </div>
      </Card>
    </div>
  );
}
