import { Card } from '../../../componentes/ui/Card';

export function EditorSonrisaPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Editor de sonrisa</h1>
        <p className="mt-1 text-textoSecundario">Feature principal del producto.</p>
      </header>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card titulo="Lienzo">
          <div className="flex h-[420px] items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 text-textoSecundario">
            Lienzo del editor
          </div>
        </Card>

        <Card titulo="Controles">
          <div className="space-y-4 text-sm text-textoSecundario">
            <div>Preset</div>
            <div>Ancho</div>
            <div>Alto</div>
            <div>Posición</div>
            <div>Intensidad</div>
          </div>
        </Card>
      </div>
    </div>
  );
}
