export function usePacientes() {
  return {
    pacientes: [],
    cargando: false,
    error: null as string | null,
  };
}
