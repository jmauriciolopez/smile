export async function obtenerPacientes() {
  return [];
}
