import { NavLink, Outlet } from 'react-router-dom';

const items = [
  { to: '/dashboard', etiqueta: 'Dashboard' },
  { to: '/pacientes', etiqueta: 'Pacientes' },
  { to: '/casos', etiqueta: 'Casos' },
  { to: '/disenos/editor', etiqueta: 'Diseños' },
  { to: '/presupuestos', etiqueta: 'Presupuestos' },
  { to: '/seguimientos', etiqueta: 'Seguimientos' },
];

export function ShellAplicacion() {
  return (
    <div className="min-h-screen bg-fondo text-texto">
      <div className="grid min-h-screen grid-cols-[260px_1fr]">
        <aside className="border-r border-slate-200 bg-superficie p-5">
          <div className="mb-8">
            <div className="text-xl font-semibold">Smile SaaS</div>
            <div className="text-sm text-textoSecundario">Base premium</div>
          </div>

          <nav className="space-y-2">
            {items.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  [
                    'block rounded-xl px-4 py-3 text-sm transition',
                    isActive
                      ? 'bg-blue-50 font-medium text-primario'
                      : 'text-textoSecundario hover:bg-slate-50 hover:text-texto',
                  ].join(' ')
                }
              >
                {item.etiqueta}
              </NavLink>
            ))}
          </nav>
        </aside>

        <main className="p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
