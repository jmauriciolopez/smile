/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        fondo: '#F7F9FB',
        superficie: '#FFFFFF',
        primario: '#2563EB',
        texto: '#0F172A',
        textoSecundario: '#64748B'
      },
      borderRadius: {
        xl2: '1rem'
      },
      boxShadow: {
        suave: '0 6px 24px rgba(15, 23, 42, 0.06)'
      }
    },
  },
  plugins: [],
};
