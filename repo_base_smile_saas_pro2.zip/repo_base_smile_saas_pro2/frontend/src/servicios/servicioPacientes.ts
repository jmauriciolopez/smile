import { clienteApi } from './clienteApi';

export type PacienteApi = {
  id: string;
  nombre_completo: string;
  telefono?: string;
  email?: string;
  ciudad?: string;
  estado_paciente?: string;
};

export async function obtenerPacientes() {
  return clienteApi<PacienteApi[]>('/pacientes');
}

export async function obtenerPacientePorId(id: string) {
  return clienteApi<PacienteApi>(`/pacientes/${id}`);
}
