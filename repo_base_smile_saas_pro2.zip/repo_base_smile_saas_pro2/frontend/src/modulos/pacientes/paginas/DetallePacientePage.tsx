import { useParams, Link } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockPacientes } from '../../../mock/pacientes.mock';
import { mockCasos } from '../../../mock/casos.mock';
import { mockPresupuestos } from '../../../mock/presupuestos.mock';

export function DetallePacientePage() {
  const { id } = useParams();
  const paciente = mockPacientes.find((item) => item.id === id);

  if (!paciente) {
    return <div>Paciente no encontrado.</div>;
  }

  const casos = mockCasos.filter((c) => c.paciente_id === paciente.id);
  const presupuestos = mockPresupuestos.filter((p) => p.paciente_id === paciente.id);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">{paciente.nombre_completo}</h1>
        <p className="mt-1 text-textoSecundario">{paciente.telefono} · {paciente.email}</p>
      </header>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card titulo="Resumen">
          <div className="space-y-3 text-sm">
            <div><span className="text-textoSecundario">Estado:</span> <BadgeEstado texto={paciente.estado_paciente} /></div>
            <div><span className="text-textoSecundario">Ciudad:</span> {paciente.ciudad}</div>
          </div>
        </Card>

        <Card titulo="Casos clínicos">
          <div className="space-y-3">
            {casos.map((caso) => (
              <Link key={caso.id} to={`/casos/${caso.id}`} className="block rounded-xl border border-slate-200 p-3">
                <div className="font-medium">{caso.titulo}</div>
                <div className="mt-1 text-sm text-textoSecundario">{caso.motivo_consulta}</div>
              </Link>
            ))}
          </div>
        </Card>

        <Card titulo="Presupuestos">
          <div className="space-y-3">
            {presupuestos.map((presupuesto) => (
              <Link key={presupuesto.id} to={`/presupuestos/${presupuesto.id}`} className="block rounded-xl border border-slate-200 p-3">
                <div className="font-medium">USD {presupuesto.monto_total_estimado}</div>
                <div className="mt-1"><BadgeEstado texto={presupuesto.estado_presupuesto} /></div>
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
