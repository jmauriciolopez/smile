import { Link } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockPacientes } from '../../../mock/pacientes.mock';

export function PacientesPage() {
  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Pacientes</h1>
          <p className="mt-1 text-textoSecundario">Listado base con datos demo realistas.</p>
        </div>
        <button className="rounded-xl bg-primario px-4 py-2 text-sm font-medium text-white">Nuevo paciente</button>
      </header>

      <Card titulo="Listado de pacientes">
        <div className="overflow-hidden rounded-xl border border-slate-200">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 text-left text-textoSecundario">
              <tr>
                <th className="px-4 py-3">Paciente</th>
                <th className="px-4 py-3">Ciudad</th>
                <th className="px-4 py-3">Estado</th>
                <th className="px-4 py-3">Acción</th>
              </tr>
            </thead>
            <tbody>
              {mockPacientes.map((paciente) => (
                <tr key={paciente.id} className="border-t border-slate-200">
                  <td className="px-4 py-3">
                    <div className="font-medium">{paciente.nombre_completo}</div>
                    <div className="text-textoSecundario">{paciente.email}</div>
                  </td>
                  <td className="px-4 py-3">{paciente.ciudad}</td>
                  <td className="px-4 py-3"><BadgeEstado texto={paciente.estado_paciente} /></td>
                  <td className="px-4 py-3">
                    <Link className="text-primario" to={`/pacientes/${paciente.id}`}>Ver detalle</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
