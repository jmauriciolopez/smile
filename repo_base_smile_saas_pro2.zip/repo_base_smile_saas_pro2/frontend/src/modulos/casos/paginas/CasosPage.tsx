import { Link } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockCasos } from '../../../mock/casos.mock';

export function CasosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Casos clínicos</h1>
        <p className="mt-1 text-textoSecundario">Centro operativo de tratamientos.</p>
      </header>

      <Card titulo="Listado de casos">
        <div className="space-y-3">
          {mockCasos.map((caso) => (
            <Link key={caso.id} to={`/casos/${caso.id}`} className="block rounded-2xl border border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">{caso.titulo}</div>
                  <div className="mt-1 text-sm text-textoSecundario">{caso.paciente_nombre}</div>
                </div>
                <BadgeEstado texto={caso.estado_caso} />
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
