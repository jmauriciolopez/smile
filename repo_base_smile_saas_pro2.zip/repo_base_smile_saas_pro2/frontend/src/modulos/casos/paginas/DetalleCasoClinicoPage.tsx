import { Link, useParams } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockCasos } from '../../../mock/casos.mock';
import { mockPresupuestos } from '../../../mock/presupuestos.mock';

export function DetalleCasoClinicoPage() {
  const { id } = useParams();
  const caso = mockCasos.find((item) => item.id === id);
  const presupuesto = mockPresupuestos[0];

  if (!caso) return <div>Caso no encontrado.</div>;

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-semibold">{caso.titulo}</h1>
          <p className="mt-1 text-textoSecundario">{caso.paciente_nombre}</p>
        </div>
        <Link className="rounded-xl bg-primario px-4 py-2 text-sm font-medium text-white" to={`/disenos/editor/${caso.id}`}>
          Abrir editor
        </Link>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card titulo="Resumen del caso">
          <div className="space-y-3 text-sm">
            <div><BadgeEstado texto={caso.estado_caso} /></div>
            <div><span className="text-textoSecundario">Motivo:</span> {caso.motivo_consulta}</div>
          </div>
        </Card>

        <Card titulo="Diseño asociado">
          <div className="space-y-3 text-sm">
            <div>Estado del diseño: <BadgeEstado texto="borrador" /></div>
            <div className="rounded-xl border border-dashed border-slate-300 p-4 text-textoSecundario">
              Before / After guardado
            </div>
          </div>
        </Card>

        <Card titulo="Fotos clínicas">
          <div className="grid grid-cols-2 gap-3">
            <div className="h-32 rounded-xl bg-slate-100" />
            <div className="h-32 rounded-xl bg-slate-100" />
          </div>
        </Card>

        <Card titulo="Presupuesto asociado">
          <Link to={`/presupuestos/${presupuesto.id}`} className="block rounded-xl border border-slate-200 p-4">
            <div className="font-medium">USD {presupuesto.monto_total_estimado}</div>
            <div className="mt-1 text-sm text-textoSecundario">Ver propuesta comercial</div>
          </Link>
        </Card>
      </div>
    </div>
  );
}
