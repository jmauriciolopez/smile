import { Link } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockPresupuestos } from '../../../mock/presupuestos.mock';

export function PresupuestosPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Presupuestos</h1>
        <p className="mt-1 text-textoSecundario">Propuestas comerciales del tratamiento.</p>
      </header>

      <Card titulo="Listado de presupuestos">
        <div className="space-y-3">
          {mockPresupuestos.map((item) => (
            <Link key={item.id} to={`/presupuestos/${item.id}`} className="block rounded-2xl border border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">{item.paciente_nombre}</div>
                  <div className="mt-1 text-sm text-textoSecundario">USD {item.monto_total_estimado} · {item.cantidad_cuotas} cuotas</div>
                </div>
                <BadgeEstado texto={item.estado_presupuesto} />
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
