import { useParams } from 'react-router-dom';
import { Card } from '../../../componentes/ui/Card';
import { BadgeEstado } from '../../../componentes/ui/BadgeEstado';
import { mockPresupuestos } from '../../../mock/presupuestos.mock';

const opciones = [
  { nombre: 'Opción esencial', monto: 1900, cuotas: 6, recomendada: false },
  { nombre: 'Opción recomendada', monto: 2400, cuotas: 6, recomendada: true },
  { nombre: 'Opción premium', monto: 3200, cuotas: 9, recomendada: false },
];

export function DetallePresupuestoPage() {
  const { id } = useParams();
  const presupuesto = mockPresupuestos.find((item) => item.id === id);

  if (!presupuesto) return <div>Presupuesto no encontrado.</div>;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold">Presupuesto</h1>
        <p className="mt-1 text-textoSecundario">{presupuesto.paciente_nombre}</p>
      </header>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card titulo="Resumen económico">
          <div className="space-y-3 text-sm">
            <div className="text-3xl font-bold">USD {presupuesto.monto_total_estimado}</div>
            <div><BadgeEstado texto={presupuesto.estado_presupuesto} /></div>
            <div className="text-textoSecundario">{presupuesto.cantidad_cuotas} cuotas</div>
          </div>
        </Card>

        <Card titulo="Próxima acción">
          <div className="text-sm text-textoSecundario">Llamar al paciente para revisar opción recomendada.</div>
        </Card>

        <Card titulo="Seguimiento reciente">
          <ul className="space-y-2 text-sm text-textoSecundario">
            <li>Presupuesto presentado</li>
            <li>Paciente pidió tiempo</li>
            <li>Se acordó contacto el viernes</li>
          </ul>
        </Card>
      </div>

      <Card titulo="Opciones de tratamiento">
        <div className="grid gap-4 md:grid-cols-3">
          {opciones.map((opcion) => (
            <div key={opcion.nombre} className={`rounded-2xl border p-4 ${opcion.recomendada ? 'border-primario bg-blue-50' : 'border-slate-200'}`}>
              <div className="font-medium">{opcion.nombre}</div>
              <div className="mt-2 text-2xl font-bold">USD {opcion.monto}</div>
              <div className="mt-1 text-sm text-textoSecundario">{opcion.cuotas} cuotas</div>
              {opcion.recomendada && <div className="mt-3 text-xs font-medium text-primario">Opción recomendada</div>}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
